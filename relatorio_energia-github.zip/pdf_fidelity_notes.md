# Critérios de fidelidade — demonstrativo NUV

O PDF de referência usa uma página A4 branca, com marca NUV escura no canto superior esquerdo, título centralizado no cabeçalho e uma regra horizontal fina. A data é alinhada à direita abaixo dessa regra. O bloco de identificação do cliente fica à esquerda, seguido por uma tabela compacta de cinco colunas: Mês Referência, Consumo, Injetado NUV, Compensação NUV e Saldo NUV.

A tabela tem cabeçalho cinza, linhas pretas finas, valores inteiros centralizados e uma última linha em que apenas as duas últimas colunas exibem `Saldo NUV` e o valor final. O rodapé contém uma linha horizontal e o endereço `nuvenergia.com.br` centralizado. A impressão foi atualizada para essas medidas, composição e arredondamento de kWh.

A marca foi extraída diretamente do PDF de referência fornecido e publicada como ativo de impressão. Ela contém o símbolo, o wordmark `nuv` e a assinatura `ENERGIA 100% DIGITAL` no enquadramento branco correto para o cabeçalho A4.

A validação de impressão identificou uma segunda página vazia causada por uma diferença de arredondamento de altura na folha A4. A área do documento foi reduzida em 1 mm, preservando a composição da primeira página e evitando a página adicional.
