# Modelo de referência: Demonstrativo de Energia Injetada

Fonte: PDF fornecido pelo usuário, `DemonstrativodeEnergiaInjetadaNUV-ELTONJUNIOPENIDO.pdf`.

O documento possui uma página com logomarca, título **Demonstrativo de Energia Injetada**, data de emissão, identificação de cliente, unidade consumidora e distribuidora. A tabela central usa as colunas **Mês Referência**, **Consumo**, **Injetado NUV**, **Compensação NUV** e **Saldo NUV**. O saldo exibido é sequencial: no primeiro mês compensado, `injetado − compensado`; nos meses posteriores, `saldo anterior + injetado − compensado`. O último saldo é o saldo pendente do cliente.
