# Cenário de validação do demonstrativo

Foi carregado no navegador um XML GD sintético compatível com a estrutura esperada, para validar o fluxo de consulta sem alterar dados do usuário.

| Mês de referência | Consumo | Injetado | Compensado | Saldo esperado |
|---|---:|---:|---:|---:|
| 2024/10 | 266 | 479 | 169 | 310 |
| 2025/01 | 237 | 396 | 0 | 706 |
| 2025/02 | 288 | 33 | 238 | 501 |

O cenário verifica que o primeiro saldo é `479 - 169 = 310` e que os ciclos seguintes acumulam o saldo anterior.

Resultado observado na interface: a UC `3003246632` foi localizada pela instalação; o filtro de mês de referência apresentou `out/24`, `jan/25` e `fev/25`; o último ciclo exibiu consumo de 288 kWh, injetado de 33 kWh, compensado de 238 kWh e saldo pendente de 501 kWh.

Também foi validado o filtro em `jan/25`: o relatório mostrou somente `out/24` e `jan/25`, com saldo pendente de 706 kWh (`310 + 396 - 0`).

## Inclusão manual e observação

- A competência manual `ago/24` (180 kWh de consumo, 250 kWh injetados e 110 kWh compensados) foi inserida antes dos ciclos importados do XML.
- O saldo foi recomposto de 140 kWh no mês manual para 41.094 kWh e 73.910 kWh nos ciclos seguintes.
- A observação “Faturamento pela média de consumo do período.” foi impressa abaixo da tabela.
- O mês de referência recebeu a formatação de impressão em negrito e o PDF foi gerado em uma página.

## Edição e exclusão de ciclos

- Cada ciclo exibido no demonstrativo possui uma chave estável composta por instalação, período-base e mês de referência. As alterações são aplicadas localmente antes da composição do demonstrativo.
- Ao salvar consumo, injetado ou compensado, a linha recebe o marcador **Editado** e uma borda âmbar; a sequência de saldo é recalculada a partir do primeiro ciclo com compensação.
- A exclusão de um ciclo importado o remove apenas do demonstrativo em memória. A exclusão de um lançamento manual remove também o lançamento local correspondente. Em ambos os casos, os ciclos seguintes são recompostos automaticamente.
- A impressão e a exportação CSV usam as linhas já recompostas, de modo que preservam os valores editados e não incluem ciclos excluídos.
- A validação técnica executada após a alteração concluiu sem erros de TypeScript (`pnpm check`) e com geração bem-sucedida da versão de produção (`pnpm build`).

## Sobrescrita de saldo NUV

- O editor de ciclos também permite informar um Saldo NUV de fechamento. Quando diferente do saldo calculado para aquela competência, esse valor torna-se a nova base de cálculo.
- Cenário de conferência: um primeiro ciclo com 400 kWh injetados e 100 kWh compensados resulta em 300 kWh. Ao ajustar o saldo do ciclo seguinte para 500 kWh, o terceiro ciclo com 30 kWh injetados e 90 kWh compensados encerra em 440 kWh (`500 + 30 - 90`).
- O demonstrativo impresso e o CSV reutilizam a mesma sequência recomposta exibida na tela.

## Consolidação por posto horário

- Para um mesmo ciclo, linhas repetidas do mesmo `Posto_horario` não são mais acumuladas. O leitor preserva a maior leitura disponível por campo naquele posto e soma somente os postos distintos, como `PONTA`, `FORAP` e `INTER`.
- A planilha de referência demonstrou que o recebimento esperado é a soma de uma leitura PONTA e uma leitura FORAP: 13,44 kWh + 696,64 kWh = 710,08 kWh para a competência 2026/01 mostrada.
- A conferência no XML de referência identificou ciclos onde o recebimento era duplicado pela leitura anterior; por exemplo, 37,94 kWh passa a 18,97 kWh após a consolidação do posto.

## Geração própria com prioridade de abatimento

- Cada ciclo passa a registrar `Qtd_geracao` como **Geração própria**. Em lançamentos manuais e edições, esse campo também pode ser informado diretamente.
- A compensação NUV efetiva é limitada por `min(compensação informada, máximo(consumo − geração própria, 0))`. Essa é a compensação exibida na tela, exportada no CSV e usada no cálculo de saldo NUV.
- Cenário 1: consumo de 500 kWh, geração própria de 1.000 kWh e qualquer compensação registrada no GD resultam em 0 kWh de compensação NUV efetiva, pois não há consumo restante a cobrar.
- Cenário 2: consumo de 1.000 kWh, geração própria de 500 kWh e compensação de 500 kWh resultam em 500 kWh de compensação NUV efetiva, pois esse é exatamente o consumo remanescente.
