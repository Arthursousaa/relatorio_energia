// GD Portal — Centro de Operações Solar
// Estilo: informação operacional, azul-noite + Verde-Fóton, Sora para indicadores e DM Sans para leitura de dados.

import { ChangeEvent, useMemo, useRef, useState } from "react";
import {
  ArrowDownToLine,
  ArrowUpRight,
  BarChart3,
  CheckCircle2,
  ChevronRight,
  CircleAlert,
  FileCode2,
  FileSearch,
  FileText,
  Gauge,
  Info,
  Loader2,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload,
  X,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

type UcPeriod = {
  instalacao: string;
  numeroUc: string;
  sourceDate: number;
  periodo: string;
  periodoUso: string;
  modalidade: string;
  consumo: number;
  geracaoPropria: number;
  compensado: number;
  injetado: number;
  saldoAnterior: number;
  saldoOficial: number;
  saldoCalculado: number;
  diferenca: number;
  proximidadeExpiracao: string;
};

type PostReading = Pick<
  UcPeriod,
  "consumo" | "geracaoPropria" | "compensado" | "injetado" | "saldoAnterior" | "saldoOficial" | "proximidadeExpiracao"
>;

type CycleAggregation = Pick<
  UcPeriod,
  "instalacao" | "numeroUc" | "sourceDate" | "periodo" | "periodoUso" | "modalidade"
> & {
  postos: Map<string, PostReading>;
};

type StatementRow = UcPeriod & {
  saldoNuv: number;
};

type ManualCycle = {
  id: string;
  instalacao: string;
  periodoUso: string;
  consumo: number;
  geracaoPropria: number;
  injetado: number;
  compensado: number;
};

type ManualCycleForm = {
  periodo: string;
  consumo: string;
  geracaoPropria: string;
  injetado: string;
  compensado: string;
};

type CycleOverride = {
  id: string;
  instalacao: string;
  periodoUso: string;
  periodo: string;
  consumo?: number;
  geracaoPropria?: number;
  injetado?: number;
  compensado?: number;
  saldoNuv?: number;
  deleted: boolean;
};

type CycleEditForm = Pick<ManualCycleForm, "consumo" | "geracaoPropria" | "injetado" | "compensado"> & {
  saldoNuv: string;
};

type UcSummary = {
  instalacao: string;
  numeroUc: string;
  meses: number;
  consumoTotal: number;
  saldoMaisRecente: number;
};

type ParsedReport = {
  fileNames: string[];
  usina: string;
  totalLinhas: number;
  ucs: UcSummary[];
  registros: UcPeriod[];
};

const heroBackground =
  "radial-gradient(circle at 78% 18%, rgba(36,217,137,.16) 0 1px, transparent 1.5px), radial-gradient(circle at 82% 28%, rgba(123,240,180,.12) 0 12%, transparent 12.4%), linear-gradient(104deg, #081927 0%, #092b38 57%, #0f333d 100%)";

const numberFormatter = new Intl.NumberFormat("pt-BR", {
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

const formatKwh = (value: number) => `${numberFormatter.format(value)} kWh`;

const formatReferenceMonth = (period: string) => {
  const [year, month] = period.split("/");
  const months = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  return year && month ? `${months[Number(month) - 1] ?? month}/${year.slice(-2)}` : period;
};

const emptyManualCycleForm: ManualCycleForm = {
  periodo: "",
  consumo: "",
  geracaoPropria: "",
  injetado: "",
  compensado: "",
};

const emptyCycleEditForm: CycleEditForm = {
  consumo: "",
  geracaoPropria: "",
  injetado: "",
  compensado: "",
  saldoNuv: "",
};

const numericValue = (value: string | null | undefined) => {
  const raw = (value ?? "0").trim();
  // XMLs GD normalmente trazem decimais com ponto (ex.: 69316.38).
  // A normalização também aceita números exportados no formato pt-BR (69.316,38).
  const normalized = raw.includes(",")
    ? raw.replace(/\./g, "").replace(",", ".")
    : raw;
  const result = Number(normalized);
  return Number.isFinite(result) ? result : 0;
};

const normalize = (value: string) => value.replace(/\D/g, "");

const periodOrder = (period: string) => {
  const [year = "0", month = "0"] = period.split("/");
  return Number(year) * 100 + Number(month);
};

const cycleKey = (row: Pick<UcPeriod, "instalacao" | "periodo" | "periodoUso">) =>
  `${row.instalacao}::${row.periodo}::${row.periodoUso}`;

const fileIssueOrder = (fileName: string) => {
  const candidate = fileName.match(/20\d{6}/g)?.at(-1);
  return candidate ? Number(candidate) : 0;
};

function nodeText(parent: Element, tag: string, occurrence = 0) {
  return parent.getElementsByTagName(tag).item(occurrence)?.textContent ?? "";
}

function parseGDXml(xmlText: string, fileName: string): ParsedReport {
  const documentXml = new DOMParser().parseFromString(xmlText, "application/xml");
  if (documentXml.querySelector("parsererror")) {
    throw new Error("Não foi possível interpretar o XML. Confira se este é um relatório GD válido.");
  }

  const xmlLines = Array.from(documentXml.getElementsByTagName("Linha"));
  if (!xmlLines.length) {
    throw new Error("O arquivo não contém linhas de relatório GD.");
  }

  const grouped = new Map<string, CycleAggregation>();
  const sourceDate = fileIssueOrder(fileName);
  let usina = "";

  for (const item of xmlLines) {
    const instalacao = nodeText(item, "Instalacao");
    const numeroUc = nodeText(item, "Numero_uc");
    const periodo = nodeText(item, "Periodo");
    const periodoUso = nodeText(item, "Periodo_uso") || periodo;
    const modalidade = nodeText(item, "Modalidade");
    const isGeradora = modalidade.includes("Geradora");
    if (isGeradora && !usina) usina = instalacao;
    if (!instalacao || !periodo || isGeradora) continue;

    const key = `${instalacao}::${periodo}::${periodoUso}`;
      const current = grouped.get(key) ?? {
        instalacao,
        numeroUc,
        sourceDate,
        periodo,
        periodoUso,
        modalidade,
        postos: new Map<string, PostReading>(),
      };

    const postoHorario = nodeText(item, "Posto_horario").trim().toUpperCase() || "SEM_POSTO";
    const postoAtual = current.postos.get(postoHorario) ?? {
      consumo: 0,
      geracaoPropria: 0,
      compensado: 0,
      injetado: 0,
      saldoAnterior: 0,
      saldoOficial: 0,
      proximidadeExpiracao: "",
    };

    // Um ciclo pode trazer linhas repetidas para o mesmo posto. Para PONTA/FORAP,
    // conserva-se a maior leitura de cada campo no posto e soma-se somente entre postos distintos.
    postoAtual.consumo = Math.max(postoAtual.consumo, numericValue(nodeText(item, "Qtd_consumo")));
    postoAtual.geracaoPropria = Math.max(postoAtual.geracaoPropria, numericValue(nodeText(item, "Qtd_geracao")));
    postoAtual.compensado = Math.max(postoAtual.compensado, numericValue(nodeText(item, "Qtd_compensacao", 0)));
    postoAtual.injetado = Math.max(postoAtual.injetado, numericValue(nodeText(item, "Qtd_recebimento")));
    postoAtual.saldoAnterior = Math.max(postoAtual.saldoAnterior, numericValue(nodeText(item, "Qtd_saldo_ant")));
    postoAtual.saldoOficial = Math.max(postoAtual.saldoOficial, numericValue(nodeText(item, "Qtd_saldo_atual")));
    postoAtual.proximidadeExpiracao = nodeText(item, "Per_prox_saldo_exp") || postoAtual.proximidadeExpiracao;
    current.postos.set(postoHorario, postoAtual);
    grouped.set(key, current);
  }

  const registros = Array.from(grouped.values())
    .map((record) => {
      const consolidated = Array.from(record.postos.values()).reduce(
        (total, posto) => ({
          consumo: total.consumo + posto.consumo,
          geracaoPropria: total.geracaoPropria + posto.geracaoPropria,
          compensado: total.compensado + posto.compensado,
          injetado: total.injetado + posto.injetado,
          saldoAnterior: total.saldoAnterior + posto.saldoAnterior,
          saldoOficial: total.saldoOficial + posto.saldoOficial,
          proximidadeExpiracao: posto.proximidadeExpiracao || total.proximidadeExpiracao,
        }),
        { consumo: 0, geracaoPropria: 0, compensado: 0, injetado: 0, saldoAnterior: 0, saldoOficial: 0, proximidadeExpiracao: "" },
      );
      const saldoCalculado = consolidated.saldoAnterior + consolidated.injetado - consolidated.compensado;
      return {
        ...record,
        ...consolidated,
        consumo: Number(consolidated.consumo.toFixed(2)),
        geracaoPropria: Number(consolidated.geracaoPropria.toFixed(2)),
        compensado: Number(consolidated.compensado.toFixed(2)),
        injetado: Number(consolidated.injetado.toFixed(2)),
        saldoAnterior: Number(consolidated.saldoAnterior.toFixed(2)),
        saldoOficial: Number(consolidated.saldoOficial.toFixed(2)),
        saldoCalculado: Number(saldoCalculado.toFixed(2)),
        diferenca: Number((consolidated.saldoOficial - saldoCalculado).toFixed(2)),
      };
    })
    .sort(
      (a, b) =>
        a.instalacao.localeCompare(b.instalacao) ||
        periodOrder(a.periodoUso) - periodOrder(b.periodoUso) ||
        periodOrder(a.periodo) - periodOrder(b.periodo),
    );

  if (!registros.length) {
    throw new Error("O arquivo foi lido, mas não há UCs recebedoras para consulta.");
  }

  const byUc = new Map<string, UcPeriod[]>();
  for (const registro of registros) {
    byUc.set(registro.instalacao, [...(byUc.get(registro.instalacao) ?? []), registro]);
  }

  const ucs = Array.from(byUc.values())
    .map((rows) => {
      const recent = [...rows].sort((a, b) => periodOrder(b.periodoUso) - periodOrder(a.periodoUso))[0];
      return {
        instalacao: rows[0].instalacao,
        numeroUc: rows[0].numeroUc,
        meses: rows.length,
        consumoTotal: rows.reduce((sum, row) => sum + row.consumo, 0),
        saldoMaisRecente: recent.saldoOficial,
      };
    })
    .sort((a, b) => b.consumoTotal - a.consumoTotal);

  return { fileNames: [fileName], usina: usina || "—", totalLinhas: xmlLines.length, ucs, registros };
}

function consolidateReports(parts: ParsedReport[]): ParsedReport {
  const recordsByCycle = new Map<string, UcPeriod>();
  const sourceNames = new Set<string>();
  let usina = "";
  let totalLinhas = 0;

  for (const part of parts) {
    part.fileNames.forEach((name) => sourceNames.add(name));
    totalLinhas += part.totalLinhas;
    if (!usina && part.usina !== "—") usina = part.usina;

    for (const record of part.registros) {
      const cycleKey = `${record.instalacao}::${record.periodo}::${record.periodoUso}`;
      const stored = recordsByCycle.get(cycleKey);
      // Arquivos mais recentes prevalecem quando há o mesmo ciclo em relatórios sobrepostos.
      if (!stored || record.sourceDate >= stored.sourceDate) recordsByCycle.set(cycleKey, record);
    }
  }

  const registros = Array.from(recordsByCycle.values()).sort(
    (a, b) =>
      a.instalacao.localeCompare(b.instalacao) ||
      periodOrder(a.periodoUso) - periodOrder(b.periodoUso) ||
      periodOrder(a.periodo) - periodOrder(b.periodo),
  );
  const byUc = new Map<string, UcPeriod[]>();
  for (const registro of registros) byUc.set(registro.instalacao, [...(byUc.get(registro.instalacao) ?? []), registro]);

  const ucs = Array.from(byUc.values())
    .map((rows) => {
      const recent = [...rows].sort((a, b) => periodOrder(b.periodoUso) - periodOrder(a.periodoUso))[0];
      return {
        instalacao: rows[0].instalacao,
        numeroUc: rows[0].numeroUc,
        meses: rows.length,
        consumoTotal: rows.reduce((sum, row) => sum + row.consumo, 0),
        saldoMaisRecente: recent.saldoOficial,
      };
    })
    .sort((a, b) => b.consumoTotal - a.consumoTotal);

  return {
    fileNames: Array.from(sourceNames).sort((a, b) => fileIssueOrder(a) - fileIssueOrder(b) || a.localeCompare(b)),
    usina: usina || "—",
    totalLinhas,
    ucs,
    registros,
  };
}

function MetricCard({
  label,
  value,
  support,
  tone = "green",
}: {
  label: string;
  value: string;
  support: string;
  tone?: "green" | "blue" | "amber" | "navy";
}) {
  const tones = {
    green: "bg-[#141615] text-[#E8F4EF] before:bg-[#00D4B6]",
    blue: "bg-[#141516] text-[#E9EEF2] before:bg-[#626AFF]",
    amber: "bg-[#181613] text-[#F6EDD9] before:bg-[#F7C45A]",
    navy: "bg-[#141516] text-[#F6F8F8] before:bg-[#00D4B6]",
  };
  return (
    <article className={cn("operation-panel relative overflow-hidden rounded-2xl border border-white/[.08] p-5 shadow-none before:absolute before:left-0 before:top-0 before:h-px before:w-full", tones[tone])}>
      <p className="text-[11px] font-semibold uppercase tracking-[0.13em] opacity-70">{label}</p>
      <p className="mt-3 font-display text-xl font-semibold tracking-[-0.04em] sm:text-2xl">{value}</p>
      <p className="mt-1 text-xs opacity-75">{support}</p>
    </article>
  );
}

function SidebarSection({
  icon: Icon,
  title,
  description,
  active = false,
}: {
  icon: typeof Gauge;
  title: string;
  description: string;
  active?: boolean;
}) {
  return (
    <div aria-label={`${title}: ${description}`} className={cn("system-nav-item group relative grid size-10 place-items-center rounded-xl transition-colors", active ? "bg-[#00D4B6]/15 text-[#00D4B6]" : "text-white/45 hover:bg-white/[.06] hover:text-white/85")} title={title}>
      <Icon className="size-[18px]" />
      <span className="pointer-events-none absolute left-12 z-30 hidden w-max rounded-lg border border-white/10 bg-[#1B1B1C] px-2.5 py-1.5 text-xs font-medium text-white shadow-xl group-hover:block">{title}</span>
    </div>
  );
}

export default function Home() {
  const [report, setReport] = useState<ParsedReport | null>(null);
  const [query, setQuery] = useState("");
  const [selectedInstallation, setSelectedInstallation] = useState("");
  const [clientName, setClientName] = useState("");
  const [distribuidora, setDistribuidora] = useState("CEMIG");
  const [manualCycles, setManualCycles] = useState<ManualCycle[]>([]);
  const [manualCycleForm, setManualCycleForm] = useState<ManualCycleForm>(emptyManualCycleForm);
  const [cycleOverrides, setCycleOverrides] = useState<CycleOverride[]>([]);
  const [editingCycleKey, setEditingCycleKey] = useState<string | null>(null);
  const [cycleEditForm, setCycleEditForm] = useState<CycleEditForm>(emptyCycleEditForm);
  const [observation, setObservation] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const suggestions = useMemo(() => {
    if (!report || query.trim().length < 2) return [];
    const rawQuery = normalize(query);
    return report.ucs
      .filter((uc) => normalize(uc.instalacao).includes(rawQuery) || normalize(uc.numeroUc).includes(rawQuery))
      .slice(0, 6);
  }, [query, report]);

  const selectedSummary = useMemo(
    () => report?.ucs.find((uc) => uc.instalacao === selectedInstallation) ?? null,
    [report, selectedInstallation],
  );

  const selectedRows = useMemo(
    () =>
      (report?.registros.filter((row) => row.instalacao === selectedInstallation) ?? []).sort(
        (a, b) => periodOrder(a.periodoUso) - periodOrder(b.periodoUso) || periodOrder(a.periodo) - periodOrder(b.periodo),
      ),
    [report, selectedInstallation],
  );

  const manualRows = useMemo<UcPeriod[]>(() => {
    const xmlMonths = new Set(selectedRows.map((row) => row.periodoUso));
    return manualCycles
      .filter((cycle) => cycle.instalacao === selectedInstallation && !xmlMonths.has(cycle.periodoUso))
      .map((cycle) => ({
        instalacao: cycle.instalacao,
        numeroUc: selectedSummary?.numeroUc ?? "",
        sourceDate: Number.MAX_SAFE_INTEGER,
        periodo: cycle.periodoUso,
        periodoUso: cycle.periodoUso,
        modalidade: "Lançamento manual",
        consumo: cycle.consumo,
        geracaoPropria: cycle.geracaoPropria,
        compensado: cycle.compensado,
        injetado: cycle.injetado,
        saldoAnterior: 0,
        saldoOficial: 0,
        saldoCalculado: 0,
        diferenca: 0,
        proximidadeExpiracao: "",
      }));
  }, [manualCycles, selectedInstallation, selectedRows, selectedSummary?.numeroUc]);

  const baseTimelineRows = useMemo(
    () =>
      [...selectedRows, ...manualRows].sort(
        (a, b) =>
          periodOrder(a.periodoUso) - periodOrder(b.periodoUso) ||
          periodOrder(a.periodo) - periodOrder(b.periodo) ||
          a.sourceDate - b.sourceDate,
      ),
    [manualRows, selectedRows],
  );

  const overrideByCycleKey = useMemo(
    () => new Map(cycleOverrides.map((override) => [override.id, override])),
    [cycleOverrides],
  );

  const timelineRows = useMemo<UcPeriod[]>(
    () =>
      baseTimelineRows.flatMap((row) => {
        const override = overrideByCycleKey.get(cycleKey(row));
        if (override?.deleted) return [];

        const consumo = override?.consumo ?? row.consumo;
        const geracaoPropria = override?.geracaoPropria ?? row.geracaoPropria;
        const injetado = override?.injetado ?? row.injetado;
        const compensadoInformado = override?.compensado ?? row.compensado;
        const consumoRemanescente = Math.max(consumo - geracaoPropria, 0);
        const compensado = Math.min(compensadoInformado, consumoRemanescente);
        const saldoCalculado = row.saldoAnterior + injetado - compensado;
        return [{
          ...row,
          consumo,
          geracaoPropria,
          injetado,
          compensado,
          saldoCalculado: Number(saldoCalculado.toFixed(2)),
          diferenca: Number((row.saldoOficial - saldoCalculado).toFixed(2)),
        }];
      }),
    [baseTimelineRows, overrideByCycleKey],
  );

  const statementRows = useMemo<StatementRow[]>(() => {
    const firstEnergyCycle = timelineRows.findIndex((row) => row.injetado > 0 || row.compensado > 0);
    if (firstEnergyCycle < 0) return [];

    let saldoNuv = 0;
    return timelineRows.slice(firstEnergyCycle).map((row, index) => {
      const calculatedSaldo = index === 0 ? row.injetado - row.compensado : saldoNuv + row.injetado - row.compensado;
      saldoNuv = overrideByCycleKey.get(cycleKey(row))?.saldoNuv ?? calculatedSaldo;
      return { ...row, saldoNuv: Number(saldoNuv.toFixed(2)) };
    });
  }, [overrideByCycleKey, timelineRows]);

  const finalStatementRow = statementRows.at(-1);
  const hasSelfGeneration = useMemo(
    () => statementRows.some((row) => row.geracaoPropria > 0),
    [statementRows],
  );

  const handleFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []);
    if (!files.length) return;
    const invalidFile = files.find((file) => !file.name.toLowerCase().endsWith(".xml"));
    if (invalidFile) {
      setError(`O arquivo ${invalidFile.name} não é um XML de relatório GD.`);
      return;
    }

    setIsLoading(true);
    setError("");
    try {
      const orderedFiles = [...files].sort((a, b) => fileIssueOrder(a.name) - fileIssueOrder(b.name) || a.name.localeCompare(b.name));
      const incomingParts = await Promise.all(
        orderedFiles.map(async (file) => parseGDXml(await file.text(), file.name)),
      );
      setReport(consolidateReports(report ? [report, ...incomingParts] : incomingParts));
      setQuery("");
      setSelectedInstallation("");
      setClientName("");
      setManualCycleForm(emptyManualCycleForm);
      setObservation("");
    } catch (parseError) {
      if (!report) setReport(null);
      setSelectedInstallation("");
      setError(parseError instanceof Error ? parseError.message : "Não foi possível processar os arquivos selecionados.");
    } finally {
      setIsLoading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const selectUC = (uc: UcSummary) => {
    setSelectedInstallation(uc.instalacao);
    setQuery(uc.instalacao);
    setError("");
    setManualCycleForm(emptyManualCycleForm);
    setEditingCycleKey(null);
    setCycleEditForm(emptyCycleEditForm);
    setObservation("");
  };

  const requestSearch = () => {
    if (!report) return;
    const exact = report.ucs.find(
      (uc) => normalize(uc.instalacao) === normalize(query) || normalize(uc.numeroUc) === normalize(query),
    );
    if (exact) {
      selectUC(exact);
      return;
    }
    if (suggestions.length === 1) {
      selectUC(suggestions[0]);
      return;
    }
    setError("Não encontrei uma UC exata. Escolha uma opção sugerida ou revise o número informado.");
  };

  const resetReport = () => {
    setReport(null);
    setQuery("");
    setSelectedInstallation("");
    setClientName("");
    setManualCycles([]);
    setManualCycleForm(emptyManualCycleForm);
    setCycleOverrides([]);
    setEditingCycleKey(null);
    setCycleEditForm(emptyCycleEditForm);
    setObservation("");
    setError("");
    if (inputRef.current) inputRef.current.value = "";
  };

  const exportCsv = () => {
    if (!selectedSummary || !statementRows.length) return;
    const headings = [
      "Mês de referência",
      "Período-base",
      "Consumo (kWh)",
      "Geração própria (kWh)",
      "Injetado NUV (kWh)",
      "Compensação NUV (kWh)",
      "Saldo NUV (kWh)",
    ];
    const csvRows = statementRows.map((row) => [
      row.periodoUso,
      row.periodo,
      row.consumo,
      row.geracaoPropria,
      row.injetado,
      row.compensado,
      row.saldoNuv,
    ]);
    const csv = [headings, ...csvRows]
      .map((line) => line.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(";"))
      .join("\n");
    const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8;" });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    link.download = `demonstrativo-energia-injetada-uc-${selectedSummary.instalacao}.csv`;
    link.click();
    URL.revokeObjectURL(href);
  };

  const updateManualCycleField = (field: keyof ManualCycleForm, value: string) => {
    setManualCycleForm((current) => ({ ...current, [field]: value }));
  };

  const addManualCycle = () => {
    if (!selectedSummary || !manualCycleForm.periodo) {
      setError("Informe o mês de referência para adicionar a competência manual.");
      return;
    }
    const periodoUso = manualCycleForm.periodo.replace("-", "/");
    const existsInXml = selectedRows.some((row) => row.periodoUso === periodoUso);
    const existsManually = manualCycles.some(
      (cycle) => cycle.instalacao === selectedSummary.instalacao && cycle.periodoUso === periodoUso,
    );
    if (existsInXml || existsManually) {
      setError("Esta competência já existe para a UC. Escolha outro mês ou revise o XML GD.");
      return;
    }
    setManualCycles((current) => [
      ...current,
      {
        id: `${selectedSummary.instalacao}-${periodoUso}-${Date.now()}`,
        instalacao: selectedSummary.instalacao,
        periodoUso,
        consumo: numericValue(manualCycleForm.consumo),
        geracaoPropria: numericValue(manualCycleForm.geracaoPropria),
        injetado: numericValue(manualCycleForm.injetado),
        compensado: numericValue(manualCycleForm.compensado),
      },
    ]);
    setManualCycleForm(emptyManualCycleForm);
    setError("");
  };

  const removeManualCycle = (id: string) => {
    const cycle = manualCycles.find((item) => item.id === id);
    if (cycle) {
      const key = cycleKey({
        instalacao: cycle.instalacao,
        periodo: cycle.periodoUso,
        periodoUso: cycle.periodoUso,
      });
      setCycleOverrides((current) => current.filter((override) => override.id !== key));
    }
    setManualCycles((current) => current.filter((cycle) => cycle.id !== id));
  };

  const updateCycleEditField = (field: keyof CycleEditForm, value: string) => {
    setCycleEditForm((current) => ({ ...current, [field]: value }));
  };

  const openCycleEditor = (row: StatementRow) => {
    setEditingCycleKey(cycleKey(row));
    setCycleEditForm({
      consumo: String(row.consumo),
      geracaoPropria: String(row.geracaoPropria),
      injetado: String(row.injetado),
      compensado: String(row.compensado),
      saldoNuv: String(row.saldoNuv),
    });
    setError("");
  };

  const cancelCycleEdit = () => {
    setEditingCycleKey(null);
    setCycleEditForm(emptyCycleEditForm);
  };

  const saveCycleEdit = () => {
    if (!editingCycleKey) return;
    const sourceRow = baseTimelineRows.find((row) => cycleKey(row) === editingCycleKey);
    if (!sourceRow) {
      setError("Não foi possível localizar o ciclo original para registrar a alteração.");
      return;
    }

    const values = {
      consumo: Number(numericValue(cycleEditForm.consumo).toFixed(2)),
      geracaoPropria: Number(numericValue(cycleEditForm.geracaoPropria).toFixed(2)),
      injetado: Number(numericValue(cycleEditForm.injetado).toFixed(2)),
      compensado: Number(
        Math.min(
          numericValue(cycleEditForm.compensado),
          Math.max(numericValue(cycleEditForm.consumo) - numericValue(cycleEditForm.geracaoPropria), 0),
        ).toFixed(2),
      ),
    };
    const sourceCompensacaoNuv = Math.min(sourceRow.compensado, Math.max(sourceRow.consumo - sourceRow.geracaoPropria, 0));
    const matchesSourceValues =
      values.consumo === sourceRow.consumo &&
      values.geracaoPropria === sourceRow.geracaoPropria &&
      values.injetado === sourceRow.injetado &&
      values.compensado === sourceCompensacaoNuv;
    const statementIndex = statementRows.findIndex((row) => cycleKey(row) === editingCycleKey);
    const previousSaldo = statementIndex > 0 ? statementRows[statementIndex - 1].saldoNuv : 0;
    const calculatedSaldo = Number(
      (statementIndex === 0 ? values.injetado - values.compensado : previousSaldo + values.injetado - values.compensado).toFixed(2),
    );
    const saldoNuv = Number(numericValue(cycleEditForm.saldoNuv).toFixed(2));
    const shouldOverrideSaldo = saldoNuv !== calculatedSaldo;

    setCycleOverrides((current) => {
      if (matchesSourceValues && !shouldOverrideSaldo) return current.filter((override) => override.id !== editingCycleKey);
      const override: CycleOverride = {
        id: editingCycleKey,
        instalacao: sourceRow.instalacao,
        periodoUso: sourceRow.periodoUso,
        periodo: sourceRow.periodo,
        ...values,
        ...(shouldOverrideSaldo ? { saldoNuv } : {}),
        deleted: false,
      };
      return [...current.filter((item) => item.id !== editingCycleKey), override];
    });
    setEditingCycleKey(null);
    setCycleEditForm(emptyCycleEditForm);
    setError("");
  };

  const deleteCycle = (row: StatementRow) => {
    const reference = formatReferenceMonth(row.periodoUso);
    if (!window.confirm(`Excluir a competência ${reference}? O saldo dos meses seguintes será recalculado.`)) return;

    const key = cycleKey(row);
    if (row.modalidade === "Lançamento manual") {
      const manualCycle = manualCycles.find(
        (cycle) => cycle.instalacao === row.instalacao && cycle.periodoUso === row.periodoUso,
      );
      if (manualCycle) removeManualCycle(manualCycle.id);
    } else {
      setCycleOverrides((current) => [
        ...current.filter((override) => override.id !== key),
        {
          id: key,
          instalacao: row.instalacao,
          periodoUso: row.periodoUso,
          periodo: row.periodo,
          deleted: true,
        },
      ]);
    }
    if (editingCycleKey === key) cancelCycleEdit();
    setError("");
  };

  return (
    <div className="system-shell min-h-screen bg-[#080808] text-[#F0F0F0]">
      <div className="min-h-screen lg:grid lg:grid-cols-[56px_minmax(0,1fr)]">
        <aside className="system-rail relative z-30 hidden min-h-screen flex-col items-center border-r border-white/[.08] bg-[#111112] py-4 text-white lg:flex">
          <div className="grid size-8 place-items-center overflow-hidden rounded-full border border-[#00D4B6]/35 bg-[#0F3432] p-1.5">
            <Zap aria-label="Marca GD" className="size-full text-[#00D4B6]" strokeWidth={1.9} />
          </div>
          <nav className="mt-8 flex flex-col gap-3" aria-label="Etapas do demonstrativo GD">
            <SidebarSection active icon={Upload} title="Importar XML" description="Carregar arquivo GD" />
            <SidebarSection icon={Search} title="Consultar UC" description="Localizar unidade consumidora" />
            <SidebarSection icon={FileText} title="Demonstrativo" description="Conferir saldos por ciclo" />
            <SidebarSection icon={Gauge} title="Conferência" description="Acompanhar créditos" />
          </nav>
          <div className="mt-auto flex flex-col items-center gap-3 border-t border-white/[.08] pt-4">
            <div className="grid size-9 place-items-center rounded-xl text-[#00D4B6]" title="Processamento local"><ShieldCheck className="size-[18px]" /></div>
            <div className="grid size-8 place-items-center rounded-full border border-white/10 bg-white/[.04] text-white/60" title="Leitura operacional"><Sparkles className="size-3.5" /></div>
          </div>
        </aside>

        <main className="min-w-0">
          <section className="relative overflow-hidden border-b border-white/[.07] bg-[#090909] px-5 py-7 sm:px-8 lg:px-9 lg:py-8">
            <div className="relative mx-auto max-w-none operation-reveal">
              <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                <div>
                  <div className="mb-2 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.16em] text-[#00D4B6]">
                    <span className="size-1.5 rounded-full bg-[#00D4B6] shadow-[0_0_12px_rgba(0,212,182,.8)]" />
                    GD · CONFERÊNCIA DE CRÉDITOS
                  </div>
                  <h1 className="font-display text-[1.45rem] font-semibold tracking-[-0.045em] text-[#F5F5F5] sm:text-[1.7rem]">Gerenciamento de Créditos GD</h1>
                  <p className="mt-1 text-sm text-white/45">Importe o XML, consulte a UC e gere o demonstrativo de energia.</p>
                </div>
                <div className="technical-status flex items-center gap-3 rounded-xl border border-white/[.08] bg-[#151515] px-4 py-3 text-white shadow-[0_16px_30px_rgba(0,0,0,.22)]">
                  <div className={cn("grid size-9 place-items-center rounded-lg", report ? "bg-[#00D4B6] text-[#0B1111]" : "bg-white/[.06] text-white/50")}>
                    {report ? <CheckCircle2 className="size-4" /> : <FileCode2 className="size-4" />}
                  </div>
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-[.13em] text-white/50">Arquivo atual</p>
                    <p className="mt-0.5 max-w-[205px] truncate text-sm font-medium">{report ? (report.fileNames.length === 1 ? report.fileNames[0] : `${report.fileNames.length} arquivos consolidados`) : "Nenhum XML selecionado"}</p>
                  </div>
                  {report && (
                    <button aria-label="Remover arquivo" className="rounded-lg p-1 text-white/55 transition-colors hover:bg-white/10 hover:text-white" onClick={resetReport}>
                      <X className="size-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </section>

          <div className="mx-auto max-w-none px-5 py-6 sm:px-8 lg:px-9 lg:py-7">
            <section className="operation-panel technical-panel relative overflow-hidden border border-white/[.08] bg-[#151515] operation-reveal operation-reveal-delay">
              <div className="absolute left-0 top-0 h-full w-1 bg-[#00D4B6]" />
              <div className="flex flex-col gap-5 p-5 sm:p-6 lg:flex-row lg:items-center lg:justify-between">
                <div className="flex gap-4">
                  <div className="grid size-11 shrink-0 place-items-center rounded-xl border border-[#00D4B6]/15 bg-[#00D4B6]/10 text-[#00D4B6]">
                    <Upload className="size-5" />
                  </div>
                  <div>
                    <p className="font-display text-base font-semibold tracking-[-0.035em] text-[#F4F4F4]">Importar relatório GD</p>
                    <p className="mt-1 max-w-xl text-sm leading-5 text-white/45">
                      Selecione um ou mais XMLs da distribuidora. Os dados serão consolidados por UC e competência automaticamente.
                    </p>
                    <div aria-hidden="true" className="operation-flow-strip mt-3"><span>XML</span><i /><span>UC</span><i /><span>SALDO</span></div>
                  </div>
                </div>
                <div className="flex flex-wrap gap-3 lg:shrink-0">
                  <input accept=".xml,text/xml,application/xml" className="hidden" multiple onChange={handleFile} ref={inputRef} type="file" />
                  <Button className="h-11 gap-2 rounded-xl bg-[#00D4B6] px-5 font-semibold text-[#071211] shadow-[0_8px_18px_rgba(0,212,182,.16)] transition-transform hover:bg-[#28E5CD] active:scale-[.97]" disabled={isLoading} onClick={() => inputRef.current?.click()}>
                    {isLoading ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />}
                    {isLoading ? "Consolidando..." : report ? "Adicionar XMLs" : "Selecionar XMLs"}
                  </Button>
                  {report && (
                    <Button className="h-11 gap-2 rounded-xl border-white/[.12] bg-white/[.04] px-4 text-white/75 hover:bg-white/[.08]" onClick={resetReport} variant="outline">
                      <RefreshCw className="size-4" />
                      Limpar
                    </Button>
                  )}
                </div>
              </div>
              {error && (
                <div className="mx-5 mb-5 flex items-start gap-2 rounded-xl border border-[#F7C45A]/25 bg-[#F7C45A]/10 px-4 py-3 text-sm text-[#F7D583] sm:mx-6">
                  <CircleAlert className="mt-0.5 size-4 shrink-0" />
                  {error}
                </div>
              )}
            </section>

            {report ? (
              <>
                <section className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                  <MetricCard label="Usina geradora" support="Identificada no XML" tone="navy" value={report.usina} />
                  <MetricCard label="Arquivos GD" support="Histórico consolidado localmente" tone="amber" value={report.fileNames.length.toLocaleString("pt-BR")} />
                  <MetricCard label="UCs encontradas" support={`${report.totalLinhas.toLocaleString("pt-BR")} linhas lidas no XML`} tone="green" value={report.ucs.length.toLocaleString("pt-BR")} />
                  <MetricCard label="Competências" support="Histórico disponível no arquivo" tone="blue" value={`${new Set(report.registros.map((item) => item.periodo)).size} meses`} />
                </section>

                <section className="operation-panel technical-panel mt-6 border border-white/[.08] bg-[#151515] p-5 sm:p-6">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-[#00D4B6]">
                        <Search className="size-4" />
                        <p className="text-xs font-semibold uppercase tracking-[.14em]">Consulta individual</p>
                      </div>
                      <h2 className="mt-2 font-display text-xl font-semibold tracking-[-0.045em] text-[#F2F2F2]">Qual UC você quer analisar?</h2>
                      <p className="mt-1 text-sm text-white/45">Digite a instalação ou o número da UC, com ou sem pontuação.</p>
                    </div>
                    <p className="text-xs text-white/35">Exemplo: <span className="font-medium text-white/65">3012357588</span></p>
                  </div>

                  <div className="relative mt-5 flex flex-col gap-3 sm:flex-row">
                    <div className="relative flex-1">
                      <Search className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-white/35" />
                      <Input
                        className="h-12 rounded-xl border-white/[.12] bg-[#0E0E0E] pl-11 font-medium text-[#F2F4F4] placeholder:text-white/25 focus-visible:border-[#00D4B6] focus-visible:ring-[#00D4B6]/20"
                        onChange={(event) => setQuery(event.target.value)}
                        onKeyDown={(event) => {
                          if (event.key === "Enter") requestSearch();
                        }}
                        placeholder="Número da instalação ou da UC"
                        value={query}
                      />
                      {suggestions.length > 0 && query !== selectedInstallation && (
                        <div className="absolute z-20 mt-2 w-full overflow-hidden rounded-xl border border-white/[.1] bg-[#1A1A1A] p-1 shadow-[0_16px_30px_rgba(0,0,0,.35)]">
                          {suggestions.map((uc) => (
                            <button className="flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left transition-colors hover:bg-[#00D4B6]/10" key={uc.instalacao} onClick={() => selectUC(uc)}>
                              <span>
                                <span className="block text-sm font-semibold text-white">{uc.instalacao}</span>
                                <span className="mt-0.5 block text-xs text-white/40">UC {uc.numeroUc}</span>
                              </span>
                              <ChevronRight className="size-4 text-[#00D4B6]" />
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                    <Button className="h-12 gap-2 rounded-xl bg-[#00D4B6] px-6 font-semibold text-[#071211] hover:bg-[#28E5CD] active:scale-[.97]" onClick={requestSearch}>
                      Consultar UC
                      <ArrowUpRight className="size-4" />
                    </Button>
                  </div>

                  {selectedSummary && (
                    <div className="mt-4 rounded-xl border border-[#00D4B6]/15 bg-[#00D4B6]/[.06] px-4 py-3">
                      <p className="text-[10px] font-semibold uppercase tracking-[.13em] text-[#00D4B6]">Demonstrativo completo</p>
                      <p className="mt-1 text-sm text-white/50">O relatório reúne todos os meses de referência a partir do primeiro crédito recebido ou da primeira compensação e apresenta o saldo NUV pendente no encerramento.</p>
                    </div>
                  )}
                </section>

                {selectedSummary && finalStatementRow ? (
                  <section className="mt-6 print:mt-0" id="relatorio-uc">
                    <article className="hidden print:block print-document">
                      <header className="print-header">
                        <div className="print-brand">
                          <div aria-label="NUV Energia" className="print-brand-wordmark"><strong>nuv</strong><span>energia</span></div>
                        </div>
                        <h1>Demonstrativo de Energia Injetada</h1>
                      </header>
                      <p className="print-date"><strong>Data:</strong> {new Date().toLocaleDateString("pt-BR")}</p>
                      <div className="print-ident space-y-1 text-[11pt]">
                        <p><strong>Cliente:</strong> {clientName || "Não informado"}</p>
                        <p><strong>Unidade Consumidora:</strong> {selectedSummary.instalacao}</p>
                        <p><strong>Distribuidora:</strong> {distribuidora || "Não informada"}</p>
                      </div>
                      <table className={cn("print-table w-full border-collapse text-center text-[10pt]", !hasSelfGeneration && "print-table-no-self-generation")}>
                        <colgroup>
                          <col className="print-col-reference" />
                          <col className="print-col-consumption" />
                          {hasSelfGeneration && <col className="print-col-self-generation" />}
                          <col className="print-col-injected" />
                          <col className="print-col-compensation" />
                          <col className="print-col-balance" />
                        </colgroup>
                        <thead>
                          <tr>
                            <th>Mês Referência</th>
                            <th>Consumo</th>
                            {hasSelfGeneration && <th>Geração própria</th>}
                            <th>Injetado NUV</th>
                            <th>Compensação NUV</th>
                            <th>Saldo NUV</th>
                          </tr>
                        </thead>
                        <tbody>
                          {statementRows.map((row) => (
                            <tr key={`print-${row.instalacao}-${row.periodo}-${row.periodoUso}`}>
                              <td className="print-reference-month">{formatReferenceMonth(row.periodoUso)}</td>
                              <td>{numberFormatter.format(Math.round(row.consumo))}</td>
                              {hasSelfGeneration && <td>{numberFormatter.format(Math.round(row.geracaoPropria))}</td>}
                              <td>{numberFormatter.format(Math.round(row.injetado))}</td>
                              <td>{numberFormatter.format(Math.round(row.compensado))}</td>
                              <td>{numberFormatter.format(Math.round(row.saldoNuv))}</td>
                            </tr>
                          ))}
                          <tr className="print-total-row">
                            <td className="print-total-empty" colSpan={hasSelfGeneration ? 4 : 3} />
                            <td><strong>Saldo NUV</strong></td>
                            <td><strong>{numberFormatter.format(Math.round(finalStatementRow.saldoNuv))}</strong></td>
                          </tr>
                        </tbody>
                      </table>
                      {observation.trim() && (
                        <div className="print-observation">
                          <strong>Observação:</strong> {observation.trim()}
                        </div>
                      )}
                      <footer>nuvenergia.com.br</footer>
                    </article>

                    <div className="mb-4 flex flex-col gap-4 print:hidden lg:flex-row lg:items-end lg:justify-between">
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-[.14em] text-[#0E8A56]">Demonstrativo individual</p>
                        <h2 className="mt-2 font-display text-2xl font-semibold tracking-[-.05em]">Demonstrativo de Energia Injetada</h2>
                        <p className="mt-1 text-sm text-[#667985]">UC {selectedSummary.instalacao} · geração própria priorizada antes da compensação NUV · saldo até {formatReferenceMonth(finalStatementRow.periodoUso)}</p>
                      </div>
                      <div className="flex flex-wrap gap-2 print:hidden">
                        <Button className="h-10 gap-2 rounded-xl border-[#C8D3D9] bg-white text-[#294353] hover:bg-[#F3F6F6]" onClick={() => window.print()} variant="outline">
                          <FileSearch className="size-4" />
                          Imprimir / PDF
                        </Button>
                        <Button className="h-10 gap-2 rounded-xl border-[#C8D3D9] bg-white text-[#294353] hover:bg-[#F3F6F6]" onClick={exportCsv} variant="outline">
                          <ArrowDownToLine className="size-4" />
                          Exportar CSV
                        </Button>
                      </div>
                    </div>

                    <div className="operation-panel mb-5 grid gap-3 rounded-[14px] border border-[#D9E6E8] bg-white p-4 shadow-[0_7px_18px_rgba(13,27,42,.03)] print:hidden sm:grid-cols-2 lg:grid-cols-3">
                      <label className="text-xs font-semibold uppercase tracking-[.1em] text-[#667985]">Cliente
                        <Input className="mt-2 h-10 bg-[#FBFCFC] text-sm font-medium normal-case tracking-normal" onChange={(event) => setClientName(event.target.value)} placeholder="Nome do cliente" value={clientName} />
                      </label>
                      <label className="text-xs font-semibold uppercase tracking-[.1em] text-[#667985]">Unidade consumidora
                        <div className="mt-2 flex h-10 items-center rounded-lg border border-[#D7E1E4] bg-[#F8FBFB] px-3 text-sm font-semibold normal-case tracking-normal text-[#183343]">{selectedSummary.instalacao}</div>
                      </label>
                      <label className="text-xs font-semibold uppercase tracking-[.1em] text-[#667985]">Distribuidora
                        <Input className="mt-2 h-10 bg-[#FBFCFC] text-sm font-medium normal-case tracking-normal" onChange={(event) => setDistribuidora(event.target.value)} value={distribuidora} />
                      </label>
                      <label className="text-xs font-semibold uppercase tracking-[.1em] text-[#667985] sm:col-span-2 lg:col-span-3">Observação do demonstrativo
                        <textarea className="mt-2 min-h-20 w-full resize-y rounded-lg border border-[#D7E1E4] bg-[#FBFCFC] px-3 py-2.5 text-sm font-medium normal-case tracking-normal text-[#183343] outline-none transition focus:border-[#24D989] focus:ring-2 focus:ring-[#24D989]/20" onChange={(event) => setObservation(event.target.value)} placeholder="Ex.: Faturamento referente à média de consumo do período." value={observation} />
                      </label>
                    </div>

                    <div className="operation-panel mb-5 rounded-[14px] border border-[#D9E6E8] bg-[#F8FBFB] p-4 print:hidden sm:p-5">
                      <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                        <div>
                          <p className="text-xs font-semibold uppercase tracking-[.14em] text-[#0E8A56]">Competência por média</p>
                          <h3 className="mt-1 font-display text-base font-semibold tracking-[-.035em] text-[#183343]">Adicionar mês não informado no GD</h3>
                          <p className="mt-1 max-w-2xl text-xs leading-5 text-[#667985]">Use para ciclos faturados pela média. A nova competência entra na ordem correta e todos os saldos seguintes são recalculados.</p>
                        </div>
                        <div className="flex items-center gap-1.5 rounded-full bg-[#E7FBF1] px-3 py-1.5 text-[11px] font-semibold text-[#0E8A56]">
                          <Info className="size-3.5" /> Manual
                        </div>
                      </div>

                      <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-[1.15fr_repeat(4,minmax(0,1fr))_auto]">
                        <label className="text-xs font-semibold uppercase tracking-[.1em] text-[#667985]">Mês referência
                          <Input className="mt-2 h-10 bg-white text-sm font-medium normal-case tracking-normal" onChange={(event) => updateManualCycleField("periodo", event.target.value)} type="month" value={manualCycleForm.periodo} />
                        </label>
                        <label className="text-xs font-semibold uppercase tracking-[.1em] text-[#667985]">Consumo kWh
                          <Input className="mt-2 h-10 bg-white text-sm font-medium normal-case tracking-normal" inputMode="decimal" onChange={(event) => updateManualCycleField("consumo", event.target.value)} placeholder="0" value={manualCycleForm.consumo} />
                        </label>
                        <label className="text-xs font-semibold uppercase tracking-[.1em] text-[#667985]">Geração própria kWh
                          <Input className="mt-2 h-10 bg-white text-sm font-medium normal-case tracking-normal" inputMode="decimal" onChange={(event) => updateManualCycleField("geracaoPropria", event.target.value)} placeholder="0" value={manualCycleForm.geracaoPropria} />
                        </label>
                        <label className="text-xs font-semibold uppercase tracking-[.1em] text-[#667985]">Injetado NUV kWh
                          <Input className="mt-2 h-10 bg-white text-sm font-medium normal-case tracking-normal" inputMode="decimal" onChange={(event) => updateManualCycleField("injetado", event.target.value)} placeholder="0" value={manualCycleForm.injetado} />
                        </label>
                        <label className="text-xs font-semibold uppercase tracking-[.1em] text-[#667985]">Compensação NUV kWh
                          <Input className="mt-2 h-10 bg-white text-sm font-medium normal-case tracking-normal" inputMode="decimal" onChange={(event) => updateManualCycleField("compensado", event.target.value)} placeholder="0" value={manualCycleForm.compensado} />
                        </label>
                        <Button className="mt-auto h-10 gap-2 rounded-xl bg-[#0D1B2A] px-4 font-semibold text-white hover:bg-[#183546]" onClick={addManualCycle}>
                          <Plus className="size-4" /> Adicionar
                        </Button>
                      </div>

                      {manualCycles.filter((cycle) => cycle.instalacao === selectedSummary.instalacao).length > 0 && (
                        <div className="mt-4 border-t border-[#D9E6E8] pt-3">
                          <p className="text-[10px] font-semibold uppercase tracking-[.12em] text-[#748690]">Competências manuais desta UC</p>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {manualCycles.filter((cycle) => cycle.instalacao === selectedSummary.instalacao).sort((a, b) => periodOrder(a.periodoUso) - periodOrder(b.periodoUso)).map((cycle) => (
                              <div className="flex items-center gap-2 rounded-lg border border-[#CFE3D9] bg-white py-1.5 pl-3 pr-1.5 text-xs text-[#274452]" key={cycle.id}>
                                <span className="font-semibold">{formatReferenceMonth(cycle.periodoUso)}</span>
                                <span className="text-[#6C7E88]">{formatKwh(cycle.injetado)} injetado</span>
                                <button aria-label={`Remover ${formatReferenceMonth(cycle.periodoUso)}`} className="rounded-md p-1 text-[#758993] transition-colors hover:bg-[#FFECEC] hover:text-[#B42318]" onClick={() => removeManualCycle(cycle.id)}>
                                  <Trash2 className="size-3.5" />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="grid gap-3 print:hidden sm:grid-cols-2 xl:grid-cols-5">
                      <MetricCard label={`Consumo · ${formatReferenceMonth(finalStatementRow.periodoUso)}`} support="Qtd_consumo no ciclo selecionado" tone="blue" value={formatKwh(finalStatementRow.consumo)} />
                      <MetricCard label="Geração própria" support="Prioridade no abatimento do consumo" tone="green" value={formatKwh(finalStatementRow.geracaoPropria)} />
                      <MetricCard label="Injetado NUV" support="Qtd_recebimento no ciclo selecionado" tone="green" value={formatKwh(finalStatementRow.injetado)} />
                      <MetricCard label="Compensação NUV" support="Limitada ao consumo remanescente" tone="amber" value={formatKwh(finalStatementRow.compensado)} />
                      <MetricCard label="Saldo pendente" support="Saldo acumulado do cliente" tone="navy" value={formatKwh(finalStatementRow.saldoNuv)} />
                    </div>

                    <div className="mt-5 grid gap-5 print:hidden xl:grid-cols-[minmax(0,1fr)_340px]">
                      <article className="operation-panel technical-panel overflow-hidden border border-[#0D1B2A]/10 bg-white">
                        <div className="flex items-center justify-between border-b border-[#E2E9EB] px-5 py-4 sm:px-6">
                          <div>
                            <h3 className="font-display text-base font-semibold tracking-[-0.035em]">Energia própria, injetada e compensada</h3>
                            <p className="mt-1 text-xs text-[#72848E]">A geração própria reduz primeiro o consumo. A compensação NUV só considera o saldo de consumo remanescente.</p>
                          </div>
                          <BarChart3 className="size-5 text-[#0E8A56]" />
                        </div>
                        <div className="overflow-x-auto">
                          <table className="w-full min-w-[1180px] text-left text-sm">
                            <thead className="bg-[#F5F8F8] text-[10px] font-semibold uppercase tracking-[.10em] text-[#647681]">
                              <tr>
                                <th className="px-5 py-3.5 sm:px-6">Mês referência</th>
                                <th className="px-3 py-3.5">Período-base</th>
                                <th className="px-3 py-3.5 text-right">Consumo</th>
                                <th className="px-3 py-3.5 text-right">Geração própria</th>
                                <th className="px-3 py-3.5 text-right">Injetado NUV</th>
                                <th className="px-3 py-3.5 text-right">Compensação NUV</th>
                                <th className="px-5 py-3.5 text-right sm:px-6">Saldo NUV</th>
                                <th className="px-5 py-3.5 text-right sm:px-6">Ações</th>
                              </tr>
                            </thead>
                            <tbody>
                              {statementRows.map((row) => {
                                const rowKey = cycleKey(row);
                                const isEditing = editingCycleKey === rowKey;
                                const isEdited = Boolean(overrideByCycleKey.get(rowKey) && !overrideByCycleKey.get(rowKey)?.deleted);
                                return (
                                  <tr className={cn("border-t border-[#ECF0F1] text-[#284250]", isEdited && "border-l-4 border-l-[#F59E0B] bg-[#FFFBEF]")} key={rowKey}>
                                    <td className="px-5 py-3.5 font-semibold sm:px-6">
                                      <div className="flex items-center gap-2">
                                        {formatReferenceMonth(row.periodoUso)}
                                        {isEdited && <span className="rounded-full bg-[#FFF0C8] px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[.08em] text-[#9A5B00]">Editado</span>}
                                      </div>
                                    </td>
                                    <td className="px-3 py-3.5 text-[#667985]">{formatReferenceMonth(row.periodo)}</td>
                                    <td className="px-3 py-3.5 text-right tabular-nums">
                                      {isEditing ? <Input aria-label={`Consumo de ${formatReferenceMonth(row.periodoUso)}`} className="ml-auto h-9 w-28 bg-white text-right text-sm" inputMode="decimal" onChange={(event) => updateCycleEditField("consumo", event.target.value)} value={cycleEditForm.consumo} /> : formatKwh(row.consumo)}
                                    </td>
                                    <td className="px-3 py-3.5 text-right tabular-nums text-[#0B6D76]">
                                      {isEditing ? <Input aria-label={`Geração própria de ${formatReferenceMonth(row.periodoUso)}`} className="ml-auto h-9 w-28 bg-white text-right text-sm" inputMode="decimal" onChange={(event) => updateCycleEditField("geracaoPropria", event.target.value)} value={cycleEditForm.geracaoPropria} /> : formatKwh(row.geracaoPropria)}
                                    </td>
                                    <td className="px-3 py-3.5 text-right tabular-nums text-[#0E8A56]">
                                      {isEditing ? <Input aria-label={`Injetado de ${formatReferenceMonth(row.periodoUso)}`} className="ml-auto h-9 w-28 bg-white text-right text-sm" inputMode="decimal" onChange={(event) => updateCycleEditField("injetado", event.target.value)} value={cycleEditForm.injetado} /> : formatKwh(row.injetado)}
                                    </td>
                                    <td className="px-3 py-3.5 text-right tabular-nums text-[#A35F00]">
                                      {isEditing ? <Input aria-label={`Compensação de ${formatReferenceMonth(row.periodoUso)}`} className="ml-auto h-9 w-28 bg-white text-right text-sm" inputMode="decimal" onChange={(event) => updateCycleEditField("compensado", event.target.value)} value={cycleEditForm.compensado} /> : formatKwh(row.compensado)}
                                    </td>
                                    <td className="px-5 py-3.5 text-right font-semibold tabular-nums text-[#102638] sm:px-6">
                                      {isEditing ? <Input aria-label={`Saldo NUV de ${formatReferenceMonth(row.periodoUso)}`} className="ml-auto h-9 w-28 border-[#0E8A56]/35 bg-[#F3FFF8] text-right text-sm font-semibold" inputMode="decimal" onChange={(event) => updateCycleEditField("saldoNuv", event.target.value)} value={cycleEditForm.saldoNuv} /> : formatKwh(row.saldoNuv)}
                                    </td>
                                    <td className="px-5 py-3.5 sm:px-6">
                                      {isEditing ? (
                                        <div className="flex justify-end gap-1.5">
                                          <button aria-label={`Salvar alterações de ${formatReferenceMonth(row.periodoUso)}`} className="rounded-lg bg-[#0D1B2A] px-2.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-[#183546]" onClick={saveCycleEdit}>Salvar</button>
                                          <button aria-label={`Cancelar alterações de ${formatReferenceMonth(row.periodoUso)}`} className="rounded-lg border border-[#C8D3D9] bg-white px-2.5 py-1.5 text-xs font-semibold text-[#526773] transition-colors hover:bg-[#F3F6F6]" onClick={cancelCycleEdit}>Cancelar</button>
                                        </div>
                                      ) : (
                                        <div className="flex justify-end gap-1">
                                          <button aria-label={`Editar ${formatReferenceMonth(row.periodoUso)}`} className="rounded-lg p-2 text-[#46606D] transition-colors hover:bg-[#EAFBF2] hover:text-[#0E8A56]" onClick={() => openCycleEditor(row)} title="Editar ciclo">
                                            <Pencil className="size-4" />
                                          </button>
                                          <button aria-label={`Excluir ${formatReferenceMonth(row.periodoUso)}`} className="rounded-lg p-2 text-[#758993] transition-colors hover:bg-[#FFECEC] hover:text-[#B42318]" onClick={() => deleteCycle(row)} title="Excluir ciclo">
                                            <Trash2 className="size-4" />
                                          </button>
                                        </div>
                                      )}
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </article>

                      <aside className="operation-panel technical-panel bg-[#0D1B2A] p-5 text-white sm:p-6">
                        <div className="flex items-center justify-between">
                          <div className="grid size-10 place-items-center rounded-xl bg-[#24D989] text-[#0D1B2A]">
                            <Gauge className="size-5" />
                          </div>
                          <span className="rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[.12em] text-[#7BF0B4]">Saldo pendente</span>
                        </div>
                        <h3 className="mt-5 font-display text-lg font-semibold tracking-[-.045em]">Fechamento da competência</h3>
                        <div className="mt-5 space-y-3 text-sm">
                          <div className="flex justify-between border-b border-white/10 pb-3"><span className="text-white/60">Mês de referência</span><strong>{formatReferenceMonth(finalStatementRow.periodoUso)}</strong></div>
                          <div className="flex justify-between border-b border-white/10 pb-3"><span className="text-white/60">− Geração própria</span><strong className="text-[#7BF0B4]">{formatKwh(finalStatementRow.geracaoPropria)}</strong></div>
                          <div className="flex justify-between border-b border-white/10 pb-3"><span className="text-white/60">+ Injetado NUV</span><strong className="text-[#7BF0B4]">{formatKwh(finalStatementRow.injetado)}</strong></div>
                          <div className="flex justify-between border-b border-white/10 pb-3"><span className="text-white/60">− Compensação NUV</span><strong className="text-[#FFD287]">{formatKwh(finalStatementRow.compensado)}</strong></div>
                          <div className="flex justify-between pt-1"><span className="font-medium text-white">= Saldo pendente</span><strong className="font-display text-base text-[#7BF0B4]">{formatKwh(finalStatementRow.saldoNuv)}</strong></div>
                        </div>
                        <div className="mt-6 rounded-xl bg-white/[.07] p-4">
                          <p className="text-[10px] font-semibold uppercase tracking-[.12em] text-white/45">Saldo NUV acumulado</p>
                          <p className="mt-1 font-display text-xl font-semibold tracking-[-.05em]">{formatKwh(finalStatementRow.saldoNuv)}</p>
                          <div className="mt-3 flex gap-2 text-xs leading-5 text-[#7BF0B4]"><CheckCircle2 className="mt-0.5 size-3.5 shrink-0" />Cálculo iniciado no primeiro crédito recebido ou compensação.</div>
                        </div>
                        {finalStatementRow.proximidadeExpiracao && <p className="mt-4 text-xs text-white/55">Próximo saldo com expiração no XML: <span className="font-semibold text-white/85">{finalStatementRow.proximidadeExpiracao}</span></p>}
                      </aside>
                    </div>
                  </section>
                ) : (
                  <section className="mt-6 grid place-items-center rounded-[22px] border border-dashed border-[#B8C8CD] bg-white/60 px-6 py-14 text-center">
                    <div className="grid size-12 place-items-center rounded-2xl bg-[#EAFBF2] text-[#0E8A56]"><Search className="size-5" /></div>
                    <h2 className="mt-4 font-display text-lg font-semibold tracking-[-.04em]">Aguardando a seleção de uma UC</h2>
                    <p className="mt-2 max-w-md text-sm leading-6 text-[#6B7D87]">Use a busca acima para localizar uma instalação e abrir o relatório individual mês a mês.</p>
                  </section>
                )}
              </>
            ) : (
              <section className="mt-6 grid gap-4 lg:grid-cols-[1.2fr_.8fr]">
                <article className="operation-panel technical-panel border border-[#0D1B2A]/10 bg-white p-6 sm:p-8">
                  <div className="flex items-center gap-3 text-[#0E8A56]"><span className="grid size-9 place-items-center rounded-xl bg-[#E7FBF1]"><FileCode2 className="size-4" /></span><span className="text-xs font-semibold uppercase tracking-[.14em]">Pronto para análise</span></div>
                  <h2 className="mt-6 max-w-xl font-display text-2xl font-semibold leading-tight tracking-[-.055em]">Leia o XML da distribuidora sem montar planilhas manualmente.</h2>
                  <p className="mt-3 max-w-xl text-sm leading-6 text-[#647681]">Depois do upload, você poderá pesquisar qualquer UC por instalação e gerar o demonstrativo completo com consumo, geração própria, injeção, compensação NUV efetiva e saldo pendente.</p>
                  <div className="mt-6 flex flex-wrap gap-2">
                    {["Consumo", "Geração própria", "Compensação NUV", "Injetado", "Saldo pendente"].map((item) => <span className="rounded-full bg-[#F1F6F6] px-3 py-1.5 text-xs font-medium text-[#3B5663]" key={item}>{item}</span>)}
                  </div>
                </article>
                <article className="operation-panel technical-panel relative overflow-hidden bg-[#0D1B2A] p-6 text-white sm:p-8">
                  <div className="absolute -right-9 -top-10 size-40 rounded-full border-[22px] border-[#24D989]/20" />
                  <div className="relative flex items-center gap-2 text-xs font-semibold uppercase tracking-[.14em] text-[#7BF0B4]"><span className="grid size-5 place-items-center rounded-md border border-[#24D989]/45"><Zap className="size-3 fill-current" /></span>Sequência do saldo</div>
                  <p className="relative mt-4 font-display text-2xl font-semibold tracking-[-.055em]">Geração própria<br /><span className="text-base text-[#7BF0B4]">abate o consumo primeiro</span><br /><span className="text-base text-white/70">Saldo: injetado − compensação NUV</span></p>
                  <div className="relative mt-6 flex items-center gap-2 text-sm font-medium text-[#7BF0B4]"><CheckCircle2 className="size-4" /> Saldo pendente por competência</div>
                </article>
              </section>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
