# Relatório GD por UC

Portal estático para importar XMLs de Geração Distribuída, consultar UCs e gerar demonstrativos com consumo, geração própria, energia injetada, compensação e saldo NUV. Todo processamento ocorre no navegador: os XMLs não são enviados a um servidor.

## Publicação gratuita

O repositório inclui o fluxo `.github/workflows/deploy-pages.yml`. Depois do primeiro envio ao GitHub, abra **Settings → Pages**, selecione **GitHub Actions** em *Build and deployment* e aguarde a execução do fluxo. A aplicação ficará disponível em `https://SEU-USUARIO.github.io/relatorio-gd-uc/`.

## Desenvolvimento local

Use Node.js 22 e pnpm 10.

```bash
pnpm install
pnpm dev
```

Para conferir a mesma compilação que será enviada ao GitHub Pages:

```bash
pnpm build:github-pages
pnpm preview
```
