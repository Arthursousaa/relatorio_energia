# Análise de consolidação por posto horário

## Imagem de referência do usuário

Os dois primeiros cortes da imagem confirmam que as linhas exibidas pertencem à mesma instalação `3010174749`, à mesma UC `7.200.858.018-05`, à mesma modalidade **Ger. Compartilhada-Recebedora** e compartilham as competências apresentadas. Para cada competência há pares repetidos de `PONTA` e `FORAP`.

| Período | Período de uso | Postos repetidos visíveis |
|---|---|---|
| 2025/12 | 2026/01 | 2 linhas PONTA e 2 linhas FORAP |
| 2025/11 | 2025/12 | 2 linhas PONTA e 2 linhas FORAP |
| 2025/10 | 2025/11 | 2 linhas PONTA e 2 linhas FORAP |

As próximas leituras conferirão os campos numéricos para determinar a regra de seleção e soma sem duplicidade.

## Valores confirmados nos cortes finais

Em cada competência, a imagem mostra duas linhas equivalentes para `PONTA` e duas para `FORAP`. A primeira linha de cada posto contém os valores úteis de consumo/compensação quando aplicável; a segunda linha repete o recebimento e pode trazer consumo sem compensação.

| Período de uso | PONTA — recebimento | FORAP — consumo | FORAP — compensação | FORAP — recebimento | Recebimento consolidado esperado |
|---|---:|---:|---:|---:|---:|
| 2026/01 | 13,44 | 520 | 420 | 696,64 | 710,08 |
| 2025/12 | 6,72 | 400 | 300 | 683,20 | 689,92 |
| 2025/11 | 4,48 | 375 | 275 | 768,32 | 772,80 |

Assim, a regra não pode somar todas as linhas do ciclo. Ela precisa consolidar uma ocorrência de `PONTA` e uma de `FORAP` por campo, evitando que o mesmo recebimento seja contado duas vezes.

## Conferência no XML de referência

O XML compartilhado no projeto contém `5.173` linhas `PONTA`, `5.835` linhas `FORAP` e `2` linhas `INTER`. Foram identificados `15` ciclos com PONTA e FORAP e mais de duas linhas. Em exemplos reais, a soma sem consolidação duplicava integralmente o recebimento:

| Instalação | Período de uso | Recebimento pela soma antiga | Recebimento por posto consolidado |
|---|---|---:|---:|
| 3005693574 | 2026/06 | 37,94 | 18,97 |
| 3013971767 | 2026/06 | 531,16 | 265,58 |

O leitor agora mantém, para cada posto (`PONTA`, `FORAP`, `INTER` ou sem posto), a maior leitura de cada campo das linhas repetidas e soma os valores apenas entre postos distintos.
