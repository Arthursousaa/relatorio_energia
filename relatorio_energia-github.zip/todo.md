# Ajustes solicitados — filtro e colunas do XML GD

- [ ] Incluir `Periodo_uso` no modelo de dados como mês de referência.
- [ ] Preservar `Periodo` no relatório como mês-base.
- [ ] Filtrar a consulta pela coluna `Instalacao`.
- [ ] Adicionar filtro de mês de referência (`Periodo_uso`) depois de selecionar a UC.
- [ ] Exibir `Qtd_consumo`, `Qtd_compensacao` e `Qtd_recebimento` com os rótulos de negócio correspondentes.
- [ ] Validar a interface contra o padrão exibido nas imagens de referência.
- [ ] Analisar o demonstrativo em PDF enviado e identificar a estrutura do documento.
- [ ] Criar uma visualização de demonstrativo individual após a seleção de UC e competência.
- [ ] Oferecer exportação do demonstrativo como PDF pela interface.
- [ ] Iniciar a sequência no primeiro mês com compensação da UC.
- [ ] Calcular o primeiro saldo como injetado menos compensado.
- [ ] Calcular os ciclos posteriores como saldo anterior mais injetado menos compensado.
- [ ] Exibir o último saldo da sequência como saldo pendente do cliente.
- [ ] Mapear a hierarquia visual e as seções do novo demonstrativo de referência.
- [ ] Reestruturar a versão de impressão para espelhar o modelo enviado.
- [ ] Validar a organização dos dados e o layout do demonstrativo revisado.
- [ ] Exibir todas as competências da UC em ordem cronológica, sem restringir a tabela ao mês selecionado.
- [ ] Mostrar apenas o Saldo NUV pendente acumulado no rodapé da tabela.
- [ ] Aceitar a seleção de múltiplos arquivos XML GD no upload.
- [ ] Consolidar UCs e competências sem duplicar ciclos já presentes entre arquivos.
- [ ] Manter a sequência de saldo NUV ao combinar históricos antigos e recentes.
- [ ] Refinar a impressão para maior fidelidade ao demonstrativo NUV de referência.
- [ ] Reproduzir a hierarquia e o alinhamento do cabeçalho do PDF NUV.
- [ ] Ajustar dimensões, tipografia, bordas e espaçamento da tabela de competências.
- [ ] Reproduzir o bloco de dados do cliente, data, rodapé e destaque do saldo final.
- [ ] Comparar uma impressão gerada com o PDF de referência antes da publicação.
- [ ] Criar o formulário para incluir manualmente uma competência ausente no XML.
- [ ] Reordenar as competências e recalcular os saldos após cada inclusão manual.
- [ ] Permitir remover uma competência adicionada manualmente antes de imprimir.
- [ ] Destacar em negrito o mês de referência na tabela impressa.
- [ ] Adicionar um campo de observação opcional ao demonstrativo da UC.
- [ ] Imprimir a observação abaixo da tabela quando houver conteúdo.
- [x] Permitir sobrescrever consumo, injetado e compensado de ciclos importados do GD.
- [x] Sinalizar visualmente ciclos alterados em relação ao XML de origem.
- [x] Permitir excluir ciclos importados ou lançados manualmente do demonstrativo.
- [x] Recalcular o saldo acumulado após editar ou excluir qualquer ciclo.
- [x] Permitir sobrescrever o Saldo NUV de uma competência e recompor os ciclos posteriores a partir desse saldo.
- [x] Consolidar PONTA e FORAP por ciclo, somando uma ocorrência de cada posto sem duplicar linhas repetidas do XML.
- [x] Adicionar o campo de geração própria aos ciclos importados e aos lançamentos manuais.
- [x] Priorizar a geração própria no abatimento do consumo antes da compensação NUV.
- [x] Exibir a geração própria e a compensação NUV efetiva na tabela, PDF e CSV.
- [x] Reestruturar o portal GD com tema escuro, navegação lateral compacta e linguagem visual alinhada ao novo sistema.
- [x] Investigar e corrigir a ausência da competência de fevereiro para a UC 3000233809 no leitor de XML.
- [x] Exibir a coluna de geração própria no PDF apenas para UCs que tenham geração registrada no GD.

- [ ] Exportar a versão independente para o repositório público `relatorio_energia`.
- [ ] Configurar e validar o GitHub Pages gratuito para `relatorio_energia`.
- [ ] Entregar o endereço público do portal fora do Manus.

- [ ] Confirmar o repositório final `relatorio_energia` após a alteração de nome informada pelo usuário.

- [ ] Enviar o código do portal para `relatorio_energia` quando a integração GitHub estiver habilitada.

- [ ] Validar o workflow de GitHub Pages em `relatorio_energia`.

- [ ] Entregar a URL final do portal publicado.
