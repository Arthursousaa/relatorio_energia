# Direção de Design — Relatório GD por UC

## Três caminhos explorados

### 1. Centro de Operações Solar
**Muito breve:** Uma mesa de controle calma e precisa, inspirada em centros de monitoramento de energia. A interface transforma dados técnicos em sinais de ação claros.
**Probabilidade:** 0.07

### 2. Caderno de Créditos Energéticos
**Muito breve:** Uma linguagem editorial clara, com tabelas e anotações que lembram conciliações financeiras. O foco é rastreabilidade e leitura cuidadosa.
**Probabilidade:** 0.04

### 3. Laboratório de Fluxos
**Muito breve:** Visual experimental baseado em trajetórias de energia entre usina e UCs. A estética enfatiza movimento e relacionamentos, não apenas números.
**Probabilidade:** 0.09

---

## Direção escolhida: Centro de Operações Solar

### Design Movement
**Information design operacional contemporâneo**, combinando a disciplina visual de um centro de controle com a nitidez de relatórios financeiros técnicos.

### Core Principles
1. **Informação antes da ornamentação:** toda forma visual deve orientar upload, consulta ou conferência de crédito.
2. **Hierarquia de decisão:** indicadores de consumo, injeção, compensação e saldo devem ser interpretáveis em poucos segundos.
3. **Contraste calmo:** superfícies claras e densas para leitura; tons escuros somente em zonas de contexto e orientação.
4. **Transparência operacional:** fórmulas, saldo calculado e saldo oficial aparecem juntos quando os dados são carregados.

### Color Philosophy
O azul-noite simboliza infraestrutura e confiança; o verde-luz representa energia que flui e crédito disponível. Fundos minerais claros reduzem fadiga visual em tabelas longas, enquanto âmbar é reservado para alertas e divergências.

### Layout Paradigm
Uma **faixa de comando vertical** à esquerda abriga identidade, status do arquivo e referências da leitura; a área principal funciona como um painel modular assimétrico, alternando zonas de ação, busca e relatório. Não há um hero central genérico: a primeira dobra já é um posto de trabalho.

### Signature Elements
1. **Linha de fluxo de energia:** uma linha verde segmentada, usada como detalhe entre estágios do processo.
2. **Painéis de leitura com arestas técnicas:** cartões com sombra baixa, cantos discretos e pequenos recortes/indicadores superiores.
3. **Pílulas de estado numérico:** indicadores verdes, azuis e âmbar para status e divergências.

### Interaction Philosophy
A interface responde como uma ferramenta de análise: upload é evidente, busca aceita números com ou sem pontuação e o relatório revelado dá foco à UC selecionada. Ações secundárias não competem com o fluxo principal.

### Animation
Usar transições rápidas de 160–240 ms com `cubic-bezier(0.23, 1, 0.32, 1)`. Resultados entram por opacidade e deslocamento vertical de 8 px; barras de KPI crescem apenas no carregamento do relatório. Respeitar `prefers-reduced-motion`.

### Typography System
**Sora** para títulos e números importantes: geométrica, precisa e com peso visual. **DM Sans** para formulários, tabelas e texto explicativo: compacta e legível. Títulos em pesos 600–700; números em 600; corpo em 400–500.

### Brand Essence
**Uma central de leitura de relatórios GD para transformar XML de distribuidora em visão confiável de cada UC.** Personalidade: precisa, serena, técnica.

### Brand Voice
Direta e operacional, sem promessas vagas. Headlines explicam a próxima ação; microcopy esclarece a origem do dado.

Exemplos:
- “Carregue o relatório. Encontre a UC. Confira o crédito.”
- “Saldo oficial da distribuidora, com cálculo de conferência ao lado.”

### Wordmark & Logo
O símbolo é um sol modular com raios em forma de circuito. O wordmark combina “GD” em Sora semibold e “Centro de Relatórios” em DM Sans, em caixa alta discreta.

### Signature Brand Color
**Verde-Fóton — #24D989**

## Style Decisions

- Utilizar o logo gráfico `gd-logo` de forma destacada na barra lateral e como favicon.
- Empregar o fundo abstrato escuro `gd-hero-bg` apenas no painel de contexto superior, sempre com texto claro e sobreposição escura para contraste.
- Não usar gradientes roxos, layouts integralmente centralizados ou a fonte Inter.
- A primeira dobra deve permanecer uma estação operacional: faixa de comando à esquerda, estado do XML e módulo de importação/consulta em primeiro plano.
- Reservar Verde-Fóton para fluxo energético, créditos positivos, progresso e ação principal; usar âmbar exclusivamente para avisos ou divergências de conferência.
- A microcopy deve sempre orientar a próxima ação e indicar a origem do dado, como “XML da distribuidora” e “saldo oficial do XML”.
- Painéis principais devem parecer instrumentos de leitura técnica: cantos discretos, marcadores de status e estrutura modular predominam sobre cartões SaaS arredondados e decorativos.
- Verde-Fóton é cor de sinal operacional — ação, progresso, fluxo e crédito positivo — enquanto grandes superfícies permanecem em azul-noite ou fundos minerais claros.
- O sol modular/circuito é repetido como motivo discreto de sistema em fluxos, divisores e indicadores, além do logotipo.
- Painéis devem adotar linguagem de instrumento: raio menor, régua de leitura Verde-Fóton e divisões internas antes de sombra decorativa.
- A linha Verde-Fóton conecta origem XML, busca da UC e saldo como motivo recorrente na barra lateral, no importador e nos estados de conferência.
- Mesmo sem XML, a primeira dobra informa de forma compacta a origem do dado, o status de processamento e o próximo passo operacional.
- A interface deve espelhar o novo sistema: fundo quase preto, barra lateral de 56 px por ícones, topo compacto e um painel de trabalho grafite com bordas discretas.
- O acento principal passa a ser o verde-água `#00D4B6`; ele sinaliza item ativo, importação, busca e estados positivos, enquanto o texto auxiliar permanece em branco de baixa opacidade.
- A composição prioriza um console de gestão, não uma página institucional: o estado do arquivo fica no topo e a ação primária aparece dentro da área de trabalho.
